import React from 'react';
import { Route, Routes } from 'react-router-dom';
import ManageAccount from './ManageAccont/ManageAccount';
import WishList from './WishList';
import ProductDetails from './ProductDetail/ProductDetail';

const Dashboard = () => {
  return (
    <Routes>
      <Route path='/ManageAccount' element={<ManageAccount />} />
      <Route path='/WishlistPage' element={<WishList />} />
      <Route path="/product/:productId" element={<ProductDetails />} />
    </Routes>
  );
};

export default Dashboard;
