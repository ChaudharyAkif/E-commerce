import { Input, Button, Typography, ConfigProvider } from "antd";
const { Title, Text } = Typography;

export default function EditProfile() {
  return (
    <div className="flex flex-col md:flex-row gap-10 p-6 md:p-10">
      {/* Sidebar */}
      <div className="w-full md:w-1/4 text-sm">
        <div className="mb-8">
          <Text strong className="text-base mb-2 block">Manage My Account</Text>
          <ul className="space-y-2">
            <li className="text-red-500 font-medium">My Profile</li>
            <li className="text-gray-400">Address Book</li>
            <li className="text-gray-400">My Payment Options</li>
          </ul>
        </div>
        <div className="mb-8">
          <Text strong className="text-base mb-2 block">My Orders</Text>
          <ul className="space-y-2">
            <li className="text-gray-400">My Returns</li>
            <li className="text-gray-400">My Cancellations</li>
          </ul>
        </div>
        <div>
          <Text strong className="text-base mb-2 block">My Wishlist</Text>
        </div>
      </div>

      {/* Form */}<ConfigProvider
  theme={{
    token: {
      colorPrimary: '#00b96b',
    },
    components: {
      Input: {
        colorTextPlaceholder: '#7e7c7c', // 👈 Set placeholder color to black
      },
    },
  }}
>

      <div className="w-full md:w-3/4 bg-white rounded shadow p-6">
        <Title level={4} className="!text-red-500 mb-6">Edit Your Profile</Title>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 [&_.ant-input]:!placeholder:black">
          <div>
            <Text>First Name</Text>
            <Input placeholder="Md" disabled />
          </div>
          <div>
            <Text>Last Name</Text>
            <Input placeholder="Rimel" disabled />
          </div>
          <div>
            <Text>Email</Text>
            <Input placeholder="rimel111@gmail.com" disabled />
          </div>
          <div>
            <Text>Address</Text>
            <Input placeholder="Kingston, 5236, United State" disabled />
          </div>
        </div>

        <div className="mt-8">
          <Text>Password Changes</Text>
          <div className="flex flex-col gap-4 mt-2 [&_.ant-input]:!placeholder:black">
            <Input.Password placeholder="Current Password" className="!placeholder-black" />
            <Input.Password placeholder="New Password" />
            <Input.Password placeholder="Confirm New Password" />
          </div>
        </div>

        <div className="mt-6 flex justify-end items-center gap-4">
          <Button>Cancel</Button>
          <Button type="primary" danger>Save Changes</Button>
        </div>
      </div>
</ConfigProvider>
    </div>
  );
}
