import React from 'react';
import JustForYou from './WishList2';
import WishlistMain from './wishlist';

const WishList = () => {
  return (
    <>
      <WishlistMain />
      <JustForYou />
      
    </>
  );
};

export default WishList;
