import React from "react";
import { useParams } from "react-router-dom";

const dummyData = {
  "1": {
    name: "Havic HV G-92 Gamepad",
    price: 192,
    image: "/images/main.jpg",
    images: [
      "/images/thumb1.jpg",
      "/images/thumb2.jpg",
      "/images/thumb3.jpg",
      "/images/thumb4.jpg"
    ],
    colors: ["#ffffff", "#ff0000"],
    description: "PlayStation 5 Controller Skin High quality vinyl..."
  }
};

const ProductDetailsPage = () => {
  const { id } = useParams(); // Get ID from URL
  const product = dummyData[id]; // fetch based on ID

  if (!product) return <p className="text-center mt-20">Product not found</p>;

  return (
    <div className="min-h-screen px-6 py-10 max-w-6xl mx-auto flex flex-col lg:flex-row gap-10">
      {/* Images and Product Detail code here (as before) */}
      {/* Paste full product layout here as before */}
      <div className="flex gap-6">
        <div className="flex flex-col gap-4">
          {product.images?.map((img, idx) => (
            <img
              key={idx}
              src={img}
              alt=""
              className="w-20 h-20 border object-contain"
            />
          ))}
        </div>
        <img
          src={product.image}
          alt={product.name}
          className="w-[400px] h-[400px] object-contain border"
        />
      </div>

      <div className="flex-1">
        <h1 className="text-2xl font-bold mb-2">{product.name}</h1>
        <p className="text-xl font-semibold text-gray-800 mb-3">
          ${product.price.toFixed(2)}
        </p>
        {/* Continue full layout as previously shared */}
      </div>
    </div>
  );
};

export default ProductDetailsPage;
