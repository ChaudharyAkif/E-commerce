import React from 'react'
import { Route, Routes } from 'react-router-dom'
import Signup from './Register/Register'
import SignIn from './Login/Login'

const AuthRoutes = () => {
  return (
    <Routes>
      <Route  path="/signup" element={<Signup /> }/>
      <Route  path="/login" element={<SignIn /> }/>
    </Routes>
  )
}

export default AuthRoutes
