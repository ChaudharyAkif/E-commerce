// src/components/ContactSection.jsx
import { Input, Button, message } from 'antd';
import { PhoneOutlined, MailOutlined } from '@ant-design/icons';
import { useState } from 'react';
const { TextArea } = Input;

export default function ContactSection() {
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const formData = new FormData(e.target);
      formData.append('_gotcha', ''); // Add honeypot field

      const response = await fetch('https://getform.io/f/bkknnxvb', {
        method: 'POST',
        body: formData,
        headers: { 'Accept': 'application/json' }
      });

      if (response.ok) {
        message.success('Message sent successfully!');
        e.target.reset();
      } else {
        throw new Error(`Server responded with ${response.status}`);
      }
    } catch (error) {
      console.error('Submission error:', error);
      message.error(error.message || 'Failed to send message. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto py-10 px-4 flex flex-col md:flex-row gap-6 bg-white">
      {/* Left Card - Contact Info */}
      <div className="w-full md:w-1/3 bg-white rounded-md shadow p-6 space-y-6">
        {/* Call To Us */}
        <div className="flex items-start gap-4">
          <div className="flex items-center justify-center bg-red-500 rounded-full p-3">
            <PhoneOutlined className='text-xl !text-white scale-x-[-1]'/>
          </div>

          <div>
            <h3 className="font-semibold text-lg">Call To Us</h3>
            <p className="text-sm text-black lg:my-5">We are available 24/7, 7 days a week.</p>
            <p className="text-sm mt-1 text-black font-medium">Phone: +8801611112222</p>
          </div>
        </div>

        <hr />

        {/* Write To Us */}
        <div className="flex items-start gap-4">
          <div className="flex items-center justify-center bg-red-500 rounded-full p-3">
            <MailOutlined className="text-xl !text-white" />
          </div>

          <div>
            <h3 className="font-semibold text-lg">Write To US</h3>
            <p className="text-sm text-black lg:my-5">Fill out our form and we will contact you within 24 hours.</p>
            <p className="text-sm mt-1 text-black font-medium">Emails: customer@exclusive.com</p>
            <p className="text-sm text-black font-medium lg:my-5">Emails: support@exclusive.com</p>
          </div>
        </div>
      </div>

      {/* Right Card - Form */}
      <form className="w-full md:w-2/3 bg-white rounded-md shadow p-6" onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <Input 
            placeholder="Your Name *" 
            name="name" 
            className="placeholder-gray-500" 
            required 
          />
          <Input 
            placeholder="Your Email *" 
            name="email" 
            type="email"
            className="placeholder-gray-500" 
            required 
          />
          <Input 
            placeholder="Your Phone" 
            name="phone" 
            className="placeholder-gray-500" 
          />
        </div>

        <TextArea
          rows={8}
          name="message"
          placeholder="Your Message"
          className="placeholder-gray-500 !my-4"
          style={{ resize: "none" }}
          required
        />

        <div className="text-right">
          <Button 
            htmlType="submit"
            type="primary" 
            loading={loading} 
            danger 
            className="bg-red-500 hover:bg-red-600 px-8 w-[170px] !h-[45px]"
          >
            Send Message
          </Button>
        </div>
      </form>
    </div>
  );
}