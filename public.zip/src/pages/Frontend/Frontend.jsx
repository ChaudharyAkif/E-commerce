import React from 'react';
import { Routes, Route } from 'react-router-dom';
// import { CartProvider } from './Home/CartContext';
import Home from './Home/Home';
import ProductPage from './Home/ProductPage';
import Checkout from './Home/CheckOut/CheckOut';
import ContactUs from './Contact Us/ContactUs';
import PageNotFound from '../Misc/PageNotFound/PageNotFound';
import CartPage from './Home/CartPage';

const Frontend = () => {
  return (
    // <CartProvider>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/product" element={<ProductPage />} />
        <Route path="/cart" element={<CartPage />} />
        <Route path="/checkout" element={<Checkout />} />
        <Route path="/contactus" element={<ContactUs />} />
        <Route path="*" element={<PageNotFound />} />
      </Routes>
    // </CartProvider>
  );
};

export default Frontend;
