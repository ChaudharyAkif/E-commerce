import React from 'react';
import ProductCard from './components/ProductCart';
import CartButton from './components/CardButton';
import { useCart } from './CartContext';

import applewatch from '../../../assets/images/applewatch.png';
import machine1 from '../../../assets/images/machine1.png';

const products = [
  {
    id: 1,
    name: 'Apple Watch Series 7',
    price: '399.99',
    description: 'Advanced health tracking with sleek design.',
    image: applewatch
  },
  {
    id: 2,
    name: 'Smart Coffee Machine',
    price: '149.49',
    description: 'Brew your coffee with smart features.',
    image: machine1
  },
];

const ProductPage = () => {
  const { addToCart, cartItems } = useCart();

  return (
    <div>
      <CartButton cartItems={cartItems} />
      <h2 className="text-center text-2xl font-bold">All Products</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 p-4">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} addToCart={addToCart} />
        ))}
      </div>
    </div>
  );
};

export default ProductPage;
