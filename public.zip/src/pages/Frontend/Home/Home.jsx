import React from 'react';
import Sale from './Sale/sale';
import ProductCartmain from './ProductCarts';
import FeaturedProducts from './FeaturedProducts;/FeaturedProducts';
// import FeaturesSection from './';
import FlashSale from './Flase Sale/Flashsale';
import FeaturesSection from './SecureProduct/SecureProduct';
import ProductCartmain2 from './ProductCarts/index copy';
import EcommerceCarousel from './ImageSlider/imageslider';
import ExploreProduct from './ProductCarts/ExploreProduct';
import ExporeProduct2 from './ProductCarts/ExploreProduct2';
import CategoryGrid from './Category/BrowserCategory';

const Home = () => {
  return (
    <>
    <EcommerceCarousel />
      <Sale title="Today's Sale" color="red-600" />
      <FlashSale />
      <ProductCartmain />
      <Sale title="Categories" color="red-600" />
      <CategoryGrid />
      <Sale title="This Month" color="red-600" />

      <ProductCartmain2 />
      <Sale title="Our Product" color="red-600" />
      <ExploreProduct />
      <ExporeProduct2 />
      <Sale title="Categories" color="red-600" />
      <Sale title="Featured" color="red-600" />
      <FeaturedProducts />
      <FeaturesSection />
    </>
  );
};

export default Home;
