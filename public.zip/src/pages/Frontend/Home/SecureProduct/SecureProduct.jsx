import React from 'react';
import { FaTruck, FaHeadset, FaMoneyBillWave, FaArrowUp } from 'react-icons/fa';
import { TbTruckDelivery } from 'react-icons/tb';
import secure from '../../../../assets/images/sucure.png';

const FeaturesSection = () => {
  // Scroll to top function
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  return (
    <>
      {/* Your existing features section - completely unchanged */}
      <div className="bg-gray-50 py-10 px-4">
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Free Delivery Feature */}
          <div className="text-center">
            <div className="flex justify-center mb-3">
              <TbTruckDelivery className="text-5xl text-white bg-black p-2 outline-8 outline-gray-500 rounded-4xl" />
            </div>
            <h3 className="font-bold uppercase text-lg mb-2">FREE AND FAST DELIVERY</h3>
            <p className="text-gray-600">Free delivery for all orders over $140</p>
          </div>

          {/* Customer Service Feature */}
          <div className="text-center">
            <div className="flex justify-center mb-3">
              <FaHeadset className="text-5xl text-white bg-black p-2 outline-8 outline-gray-500 rounded-4xl" />
            </div>
            <h3 className="font-bold uppercase text-lg mb-2">24/7 CUSTOMER SERVICE</h3>
            <p className="text-gray-600">Friendly 24/7 customer support</p>
          </div>

          {/* Money Back Feature */}
          <div className="text-center">
            <div className="flex justify-center mb-3">
              <img src={secure} className="text-5xl text-white bg-black h-12 w-12 p-2 outline-8 outline-gray-500 rounded-4xl" />
            </div>
            <h3 className="font-bold uppercase text-lg mb-2">MONEY BACK GUARANTEE</h3>
            <p className="text-gray-600">We return money within 30 days</p>
          </div>
        </div>
      </div>

      {/* Scroll-to-top arrow button */}
      <button 
        className="fixed  lg:top-85 sm:bottom-8 right-6 w-12 h-12 bg-white text-black rounded-full 
                  shadow-lg hover:bg-gray-400 hover:text-white transition-all flex items-center justify-center
                  text-xl z-50"
        onClick={scrollToTop}
        aria-label="Scroll to top"
      >
        <FaArrowUp />
      </button>
    </>
  );
};

export default FeaturesSection;