import React, { useState } from 'react';
import { Input, Button, Radio, Row, Col, Breadcrumb, Form, Checkbox, ConfigProvider } from 'antd';
import { useNavigate } from 'react-router-dom';
import { CreditCard, Truck } from 'lucide-react'; // Icon import
import lcd from '../../../../assets/images/lcd.png'; // Icon import
import game from '../../../../assets/images/game.png'; // Icon import
import visa from '../../../../assets/images/visa.png'; // Icon import
import bkash from '../../../../assets/images/bkash.png'; // Icon import
import master from '../../../../assets/images/master.png'; // Icon import
import hindicard from '../../../../assets/images/hindicard.png'; // Icon import
import './CheckOut.css'; // Icon import
import { HomeOutlined, UserOutlined, ShoppingCartOutlined, EyeOutlined, CreditCardOutlined } from '@ant-design/icons';
const Checkout = () => {
    const navigate = useNavigate();
    const [paymentMethod, setPaymentMethod] = useState('cod');

    const [checked, setChecked] = useState(false);
    const handleonChange = (e) => {
        setChecked(e.target.checked);
    };

    const handlePlaceOrder = () => {
        alert('Order Placed!');
        navigate('/thank-you');
    };

    return (
        <ConfigProvider
            theme={{
                token: {
                    colorPrimary: '#ff4d4f', // 🔴 Red primary color
                },
                components: {
                    Checkbox: {
                        colorPrimary: '#ff4d4f',            // Red checkbox tick + border when checked
                        colorPrimaryHover: '#ff7875',       // Lighter red on hover
                        colorBorder: '#ffccc7',             // Border color
                        borderRadiusSM: 4,                  // Optional: slightly round corners
                    },
                },
            }}
        >
            <div className="w-full -sm py-3">

                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="">
                        <Breadcrumb
                            className="text-sm font-sans"
                            items={[
                                {
                                    href: '/account',
                                    title: (
                                        <span className="flex items-center gap-1 text-gray-600 hover:text-black">
                                            <HomeOutlined />
                                            <span>Account</span>
                                        </span>
                                    ),
                                },
                                {
                                    href: '/account/my-account',
                                    title: (
                                        <span className="flex items-center gap-1 text-gray-600 hover:text-black">
                                            <UserOutlined />
                                            <span>My Account</span>
                                        </span>
                                    ),
                                },
                                {
                                    href: '/products',
                                    title: (
                                        <span className="flex items-center gap-1 text-gray-600 hover:text-black">
                                            <ShoppingCartOutlined />
                                            <span>Product</span>
                                        </span>
                                    ),
                                },
                                {
                                    href: '/products/view-cost',
                                    title: (
                                        <span className="flex items-center gap-1 text-gray-600 hover:text-black">
                                            <EyeOutlined />
                                            <span>View Cost</span>
                                        </span>
                                    ),
                                },
                                {
                                    title: (
                                        <span className="flex items-center gap-1 font-medium text-black">
                                            <CreditCardOutlined />
                                            <span>CheckOut</span>
                                        </span>
                                    ),
                                },
                            ]}
                        />
                    </div>
                    <div className="flex flex-col md:flex-row w-full p-8 gap-10">




                        {/* Billing Details */}
                        <div className="w-full md:w-1/2">
                            <h2 className="text-2xl font-semibold mb-6">Billing Details</h2>
                            <Form className="flex flex-col gap-4 [&_.ant-input]:!bg-gray-100 " layout='vertical'>
                                <Form.Item label="Full Name *" >
                                    <Input className="py-2 " />
                                </Form.Item>
                                <Form.Item label="Company Name">
                                    <Input className="py-2" />
                                </Form.Item>
                                <Form.Item label="Street Address">
                                    <Input className="py-2" />
                                </Form.Item>
                                <Form.Item label="Apartment, floor, etc. (optional)" >
                                    <Input className="py-2" />
                                </Form.Item>
                                <Form.Item label="Town/City*">
                                    <Input className="py-2" />
                                </Form.Item>
                                <Form.Item label="Phone Number*">
                                    <Input className="py-2" />
                                </Form.Item>
                                <Form.Item label="Email Address*">
                                    <Input className="py-2" />
                                </Form.Item>
                                <Checkbox onChange={handleonChange} className="custom-checkbo">Save this information for faster check-out next time</Checkbox>
                            </Form>
                        </div>

                        {/* Order Summary */}
                        <div className="w-full md:w-1/2 lg:mt-15">
                            <div className=" lg:w-[400px] lg:ml-20 ">
                                {/* Products */}
                                <div className="flex items-center justify-between mb-4">
                                    <div className="flex items-center gap-2">
                                        <img src={lcd} alt="LCD Monitor" className="w-10 h-10 object-cover" />
                                        <span>LCD Monitor</span>
                                    </div>
                                    <span>$650</span>
                                </div>

                                <div className="flex items-center justify-between mb-4">
                                    <div className="flex items-center gap-2">
                                        <img src={game} alt="H1 Gamepad" className="w-10 h-10 object-cover" />
                                        <span>H1 Gamepad</span>
                                    </div>
                                    <span>$1100</span>
                                </div>

                                {/* Price Summary */}
                                <div className=" pt-4 text-sm space-y-2">
                                    <div className="flex justify-between">
                                        <span>Subtotal:</span>
                                        <span>$1750</span>
                                    </div>
                                    <div className=" border-t flex justify-between my-3 pt-3">
                                        <span>Shipping:</span>
                                        <span>Free</span>
                                    </div>
                                    <div className="border-t flex justify-between font-semibold text-base pt-3">
                                        <span>Total:</span>
                                        <span>$1750</span>
                                    </div>
                                </div>

                                {/* Payment Method */}
                                <div className="mt-6 space-y-2">
                                    <Row>
                                        <Radio.Group
                                            onChange={(e) => setPaymentMethod(e.target.value)}
                                            value={paymentMethod}
                                            className="flex flex-col gap-2"
                                        >

                                            <Col span={24}>
                                                <Radio value="bank" className="custom-radio" >
                                                    <div className="flex items-center gap-24 sm:gap-80 md:gap-12 lg:gap-25 xl:gap-35 xxl:gap-50">
                                                        <span className="">Bank</span>
                                                        <div className="flex gap-3 sm:gap-4 md:gap-5 [&>img]:w-[35px] [&>img]:h-[22px] ">
                                                            <img src={bkash} alt="visa" />
                                                            <img src={visa} alt="mastercard" />
                                                            <img src={master} alt="paypal" />
                                                            <img src={hindicard} alt="paypal" />
                                                        </div>
                                                    </div>
                                                </Radio>
                                            </Col>

                                            <Col span={24}>
                                                <Radio value="cod" className="custom-radio">
                                                    <div className="flex items-center gap-2">
                                                        <Truck className="w-5 h-5" />
                                                        <span>Cash on delivery</span>
                                                    </div>
                                                </Radio>
                                            </Col>
                                        </Radio.Group>
                                    </Row>


                                </div>

                                {/* Coupon Code */}
                                <div className="flex gap-2 mt-4">
                                    <Input placeholder="Coupon Code" className="w-full !placeholder-gray-500 !border-black" />
                                    <Button type="primary" className="bg-red-500 text-white hover:bg-red-600">
                                        Apply Coupon
                                    </Button>
                                </div>

                                {/* Place Order */}
                                <Button
                                    type="primary"
                                    style={{ width: "200px" }}
                                    className="mt-4 w-full "
                                    onClick={handlePlaceOrder}
                                >
                                    Place Order
                                </Button>

                                {/* Payment Icons */}

                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </ConfigProvider>
    );
};

export default Checkout;
