import React, { Suspense } from 'react';
import { Route, Routes } from 'react-router-dom';
import Frontend from './Frontend/Frontend';
import AuthRoutes from './Auth/Routes';
import Dashboard from './Dashboard/Index';
import PageNotFound from './Misc/PageNotFound/PageNotFound';

const Index = () => {
  return (
    <>
      <Routes>
        <Route path="/*" element={<Frontend />} />
        <Route path="/dashboard/*" element={<Dashboard />} />
        <Route path="/auth/*" element={<AuthRoutes />} />
        <Route path="*" element={<PageNotFound />} />
      </Routes>
    </>
  );
};

export default Index;
